
#include <iostream>
#include <string>
#include <fstream>
#include <ctime>
#include <chrono>
#include <SFML/Graphics.hpp>

using namespace std;
using namespace sf;
#define RESET "\033[0m"
#define BLUE "\033[34m"
#define YELLOW "\033[33m"
#define RED "\033[31m"
#define MAGENTA "\033[35m"
#define GREEN "\033[32m"
#define CYAN "\033[36m"


class Person
{
protected:
    string fname;
    string lname;
    string gender;
    string contactnum;
    string address;
    string emergencycontactname;
    string emergencycontactnum;
    string medicalhistory;
    string id;
public:
    string getFname() 
    {
        return fname;
    }
    void setFname(string fname)
    {
        this->fname = fname;
    }
    string getLname() 
    {
        return lname;
    }
    void setLname(string lname)
    {
        this->lname = lname;
    }
    string getGender() 
    {
        return gender;
    }
    void setGender(string gender)
    {
        this->gender = gender; 
    }
    string getContactnum() 
    {
        return contactnum;
    }
    void setContactnum(string contactnum) 
    {
        this->contactnum = contactnum;
    }
    string getAddress()
    {
        return address; 
    }
    void setAddress(string address) 
    {
        cout << RED;
        this->address = address;
    }
    string getEmergencycontactname() 
    {
        return emergencycontactname;
    }
    void setEmergencycontactname(string emergencycontactname)
    {
        this->emergencycontactname = emergencycontactname;
    }
    string getEmergencycontactnum()
    {
        return emergencycontactnum;
    }
    void setEmergencycontactnum(string emergencycontactnum) 
    {
        this->emergencycontactnum = emergencycontactnum;
    }
    string getMedicalhistory() 
    {
        return medicalhistory;
    }
    void setMedicalhistory(string medicalhistory) 
    {
        this->medicalhistory = medicalhistory; 
    }
    string getId() 
    {
        return id;
    }
    void setId(string id)
    {
        this->id = id;
    }

    virtual void input() = 0;
    virtual void display() = 0;
};

class Verification : public Person 
{
public:
    Verification()
    {
        medicalhistory = "  ";
    }

    void verify()
    {
        char choice;
        cout << "First Time visitor (Type y for yes and n for no): ";
        cin >> choice;
        if (choice == 'y' || choice == 'Y')
        {
            input();
            display();
        }
        else if (choice == 'n' || choice == 'N') 
        {
            string id1;
            cout << "Enter your ID: ";
            cin >> id1;
            readfromfile(id1);
        }
        else
        {
            cout << "Invalid Choice!" << endl;
            cout << "Enter your details:  " << endl;
            input();
        }
    }

    void input() override
    {
        srand(time(0));
        cout << "Enter your first name: ";
        cin >> fname;
        cout << "Enter your last name: ";
        cin >> lname;
        do 
        {
            cout << "Enter your gender (f for female, m for male): ";
            cin >> gender;
        }
        while (!isValidGender(gender));
        do 
        {
            cout << "Enter your contact number: ";
            cin >> contactnum;
        }
        while (!isValidContactNumber(contactnum));
        cin.ignore();
        cout << "Enter the name of emergency contact: ";
        getline(cin, emergencycontactname);
        do
        {
            cout << "Enter the contact number of emergency contact: ";
            cin >> emergencycontactnum;
        } 
        while (!isValidContactNumber(emergencycontactnum));
        cin.ignore();
        cout << "Enter your Address: ";
        getline(cin, address);
        cout << "Enter your medical history if any: ";
        getline(cin, medicalhistory);
        id = to_string(rand() % 90000000 + 10000000);
    }

    void display() override
    {
        cout << CYAN;
        cout << "First Name: " << fname << endl;
        cout << "Last Name: " << lname << endl;
        cout << "Gender: " << gender << endl;
        cout << "Contact Number: " << contactnum << endl;
        cout << "Address: " << address << endl;
        cout << "Emergency Contact Name: " << emergencycontactname << endl;
        cout << "Emergency Contact Number: " << emergencycontactnum << endl;
        cout << "Medical History: " << medicalhistory << endl;
        cout << "ID: " << id << endl;
    }

    void saveToFile()
    {
        ofstream outfile("patient.dat", ios::binary | ios::app);
        if (!outfile)
        {
            cerr << "File could not be opened!" << endl;
            return;
        }
        outfile.write(reinterpret_cast<char*>(this), sizeof(*this));
        outfile.close();
    }

    void readfromfile(string searchId)
    {
        ifstream infile("patient.dat", ios::binary);
        if (!infile)
        {
            cerr << "File could not be opened!" << endl;
            return;
        }
        Verification v1;
        bool found = false;
        while (infile.read(reinterpret_cast<char*>(&v1), sizeof(v1)))
        {
            if (v1.getId() == searchId)
            {
                found = true;
                break;
            }
        }
        infile.close();
        if (found)
        {
            cout << "Record Found:" << endl;
            v1.display();
        }
        else
        {
            cout << "Record not found!" << endl;
        }
    }

    bool isValidGender(const string& gender)
    {
        if (gender == "m" || gender == "M" || gender=="Male" || gender=="male" || gender == "f" || gender == "F" || gender == "female"||gender=="Female")
        {
            return true;
        }
        else 
        {
            cout << "Invalid gender."<< endl;
            return false;
        }
    }

    bool isValidContactNumber(const string& number)
    {
        if (number.size() == 10 || number.size() == 11)
        {
            return true;
        }
        else 
        {
            cout << "INVALID CONTACT NUMBER!! Please enter a valid contact number: " << endl;
            return false;
        }
    }
};

class Report 
{
private:
    string report;
    string report1 = "You are totally fine!\nThank You for Visiting.\n";
public:
    Report() {}

    void setReport(string r)
    {
        report = r;
    }

    void viewReport() 
    {
        cout << "Viewing Report: " << endl;
        cout << report << endl;
    }

    void saveToFile() 
    {
        ofstream outfile("report.dat", ios::binary | ios::app);
        string report = "You are totally fine!\n Thank You :) for Visiting.\n";
        outfile.write(report.c_str(), report.size());
        outfile.close();
    }

    void readfromfile() 
    {
        ifstream infile("report.dat", ios::binary);
        string report;
        getline(infile, report);
        cout << "Report from file is :" << report << endl;
        infile.close();
    }
};

class Reason 
{
private:
    string reason;
    Report report;
public:
    Reason() {}

    void askReason()
    {
        int choice;
        cout << "Enter your reason to visit:" << endl;
        cout << "Enter 1 to book an appointment:" << endl;
        cout << "Enter 2 to view reports: " << endl;
        cin >> choice;
        cin.ignore();
        switch (choice) 
        {
            case 1:
            {
                cout << "Enter your problem: ";
                getline(cin, reason);
                break;
            }
            case 2:
            {
                report.viewReport();
                report.saveToFile();
                report.readfromfile();
                exit(0);
                break;
            }
            default:
            {
                cout << "Invalid choice!" << endl;
                break;
            }
        }
    }

    string getReason() 
    {
        return reason;
    }

    void saveToFile() 
    {
        ofstream outfile("reason.dat", ios::binary | ios::app);
        if (!outfile) 
        {
            cerr << "File could not be opened!" << endl;
            return;
        }
        size_t length = reason.size();
        outfile.write(reinterpret_cast<const char*>(&length), sizeof(length));
        outfile.write(reason.c_str(), length);
        outfile.close();
    }

    void readFromFile() 
    {
        ifstream infile("reason.dat", ios::binary);
        if (!infile)
        {
            cerr << "File could not be opened!" << endl;
            return;
        }
        size_t length;
        infile.read(reinterpret_cast<char*>(&length), sizeof(length));
        reason.resize(length);
        infile.read(&reason[0], length);
        infile.close();
    }
};

class Amount
{
private:
    int amount;
    string paymentMethod;

public:
    Amount(int a) : amount(a) {}
    Amount() : amount(0), paymentMethod("  ") {}

    void setPaymentMethod(string method)
    {
        paymentMethod = method;
    }

    string getPaymentMethod()
    {
        return paymentMethod;
    }

    int getAmount()
    {
        return amount;
    }

    void printReceipt()
    {
        cout << "Receipt:" << endl;
        cout << "Amount: " << amount << endl;
        cout << "Payment Method: " << paymentMethod << endl;
    }
};

class Nurse 
{
private:
    string name;

public:
    Nurse(string n) : name(n) {}
    Nurse() : name("  ") {}

    string getName()
    {
        return name;
    }
};

class PersonalAssistant
{
private:
    string name;
    string number;

public:
    PersonalAssistant(string n, string num) : name(n), number(num) {}
    PersonalAssistant() : name(" "), number("  ") {}

    string getName()
    {
        return name;
    }

    string getNumber()
    {
        return number;
    }
};

class DoctorDetails 
{
private:
    string names[7] = { "Doctor A", "Doctor B", "Doctor C", "Doctor D", "Doctor E", "Doctor F", "Doctor I" };
    Amount amounts[7] = { Amount(1000),Amount(5000),Amount(2500),Amount(4500),Amount(1500),Amount(2000),Amount(3000) };
    string schedules[7] = { "9:00 AM - 12:00 PM", "1:00 PM - 4:00 PM", "9:00 AM - 12:00 PM", "1:00 PM - 4:00 PM", "9:00 AM - 12:00 PM", "12 PM - 6 PM", "8 AM TO 9 PM" };
    string specialities[7] = { "Cardiology", "Neurology", "Dermatology", "Pediatrics", "Oncology", "Dentist", "Emergency Doctor" };
    Nurse nurses[7] = { Nurse("Nurse 1 "),Nurse("Nurse 3 "), Nurse("Nurse 5 "),Nurse("Nurse 7"), Nurse("Nurse 9"), Nurse("Nurse 11"),  Nurse("Nurse 13") };
    Nurse nurses2[7] = { Nurse("Nurse 2 "),Nurse("Nurse 4 "), Nurse("Nurse 6 "),Nurse("Nurse 8 "), Nurse("Nurse 10"), Nurse("Nurse 12 "),  Nurse("Nurse 14") };
    PersonalAssistant assistants[7] = { PersonalAssistant("Assistant 1", "1234567890"), PersonalAssistant("Assistant 2", "2345678901"), PersonalAssistant("Assistant 3", "3456789012"), PersonalAssistant("Assistant 4", "4567890123"), PersonalAssistant("Assistant 5", "5678901234"), PersonalAssistant("Assistant 6", "6789012345"), PersonalAssistant("Assistant 7", "7890123456") };
    int am;

public:
    DoctorDetails() {}

    void displayDoctorDetails()
    {
        for (int i = 0; i < 7; i++)
        {
            cout << "Doctor Details: " << endl;
            cout << names[i] << "  " << amounts[i].getAmount() << "  " << schedules[i] << "  " << specialities[i] << "  " << nurses[i].getName() << "  " << nurses2[i].getName() << "   " << assistants[i].getName() << endl;
        }
    }

    void chooseDoctor()
    {
        string docname;
        cout << "Enter doctor name: ";
        getline(cin, docname);
        for (int j = 0; j < 7; j++) 
        {
            if (docname == names[j]) 
            {
                am = amounts[j].getAmount();
                break;
            }
        }
        string paymentMethod;
        cout << "Enter payment method (cash or card): ";
        getline(cin, paymentMethod);
        char choice;
        cout << "Do you need number of personal assistant of doctor (Y/N)? ";
        cin >> choice;
        cin.ignore();
        if (choice == 'Y' || choice == 'y') 
        {
            for (int j = 0; j < 7; j++)
            {
                if (docname == names[j]) 
                {
                    cout << "Number: " << assistants[j].getNumber() << endl;
                    amounts[j].setPaymentMethod(paymentMethod);
                    amounts[j].printReceipt();
                    break;
                }
            }
        }
    }
};

class DateTime 
{
    string adate;
    string atime;
public:
    DateTime() {}

    void showCurrentDateTime()
    {
        auto now = chrono::system_clock::now();
        time_t currentTime = chrono::system_clock::to_time_t(now);
        tm timeInfo;
        localtime_s(&timeInfo, &currentTime);
        char buffer[26];
        asctime_s(buffer, sizeof buffer, &timeInfo);
        cout << "Current date and time is: " << buffer;
    }

    void bookAppointment()
    {
        cout << "Enter appointment date (dd-mm-yyyy): ";
        cin >> adate;
        cout << "Enter appointment time (24-hour format): ";
        cin >> atime;
    }

    void showAppointment()
    {
        cout << "Your appointment is scheduled on " << adate << " at " << atime << endl;
    }

    void saveDateToFile()
    {
        ofstream outfile("appointment.dat", ios::binary | ios::app);
        if (!outfile) 
        {
            cerr << "File could not be opened!" << endl;
            return;
        }
        outfile.write(reinterpret_cast<char*>(this), sizeof(*this));
        outfile.close();
    }

    void readDateFromFile() 
    {
        ifstream infile("appointment.dat", ios::binary);
        if (!infile) 
        {
            cerr << "File could not be opened!" << endl;
            return;
        }
        infile.read(reinterpret_cast<char*>(this), sizeof(*this));
        infile.close();
    }
};

class Patient : public Verification
{
private:
    Reason reason;
    DoctorDetails doctorDetails;
    DateTime dateTime;
public:
    Patient() : Verification() {}

    void startProcess() 
    {
        cout << RED;
        verify();
        reason.askReason();
        cout << MAGENTA;
        doctorDetails.displayDoctorDetails();
        cout << CYAN;
        doctorDetails.chooseDoctor();
        cout << YELLOW;
        dateTime.showCurrentDateTime();
        cout << GREEN;
        dateTime.bookAppointment();
        cout << RESET;
        dateTime.showAppointment();
    }

    void saveToFile()
    {
        Verification::saveToFile();
        reason.saveToFile();
        dateTime.saveDateToFile();
    }

    void readFromFile(string id) 
    {
        Verification::readfromfile(id);
        reason.readFromFile();
        dateTime.readDateFromFile();
    }

    void displayWithSFML()
    {
        sf::RenderWindow window(sf::VideoMode(800, 600), "Patient Details");

        sf::Font font;
        if (!font.loadFromFile("scorefont.ttf")) 
        {
            cerr << "Error loading font!" << endl;
            return;
        }

        sf::Text text;
        text.setFont(font);
        text.setString("Patient Details:\n" +
            getFname() + " " + getLname() + "\n" +
            "Gender: " + getGender() + "\n" +
            "Contact: " + getContactnum() + "\n" +
            "Address: " + getAddress() + "\n" +
            "Emergency Contact: " + getEmergencycontactname() + " " + getEmergencycontactnum() + "\n" +
            "Medical History: " + getMedicalhistory() + "\n" +
            "ID: " + getId());
        text.setCharacterSize(24);
        text.setFillColor(sf::Color::Blue);
        text.setPosition(50, 50);

        while (window.isOpen()) 
        {
            sf::Event event;
            while (window.pollEvent(event)) 
            {
                if (event.type == sf::Event::Closed)
                {
                    window.close();
                }
            }

            window.clear();
            window.draw(text);
            window.display();
        }
    }
};
class bye
{
    RenderWindow& windowbye;
    Texture texturebye;
    Sprite spritebye;
public:
    bye(RenderWindow& win) :windowbye(win)
    {
        if (!texturebye.loadFromFile("bye.jpg")) {
            // Error handling if image loading fails
            cout << "Can't open file..";
            return;
        }

        spritebye.setTexture(texturebye);
        while (windowbye.isOpen()) {
            // Handle events
            Event event;
            while (windowbye.pollEvent(event)) {
                if (event.type == sf::Event::KeyPressed)
                {
                    if (event.key.code == sf::Keyboard::Escape)
                    {
                        windowbye.close();
                    }
                }
                windowbye.clear();
                windowbye.draw(spritebye);
                windowbye.display();
            }

        }
    }
};
int main()
{
    // Load the image
    RenderWindow window(sf::VideoMode(800, 600), "Hospital");

    // Load the image
    Texture texture;
    if (!texture.loadFromFile("Hospital.png"))
    {
        // Error handling if image loading fails
        cout << "Can't open file..";
        return EXIT_FAILURE;
    }

    // Create a sprite and set its texture
    Sprite sprite;
    sprite.setTexture(texture);

    // Main loop
    while (window.isOpen())
    {
        // Handle events
        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::KeyPressed)
            {
                if (event.key.code == sf::Keyboard::Escape)
                {
                    window.close();
                }
            }
            window.clear();
            window.draw(sprite);
            window.display();
        }
        cout << YELLOW;
        Patient patient;
        patient.startProcess();
        patient.saveToFile();
        patient.displayWithSFML();

        RenderWindow windowbye(VideoMode(800, 600), "BYE!");
        bye B(windowbye);
    }
    return 0;
}